(() => {
  'use strict';
  const articles = window.PULSE_ARTICLES || [];
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icon = name => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const storage = {
    get(key, fallback) { try { return JSON.parse(localStorage.getItem('pulse-' + key)) ?? fallback; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem('pulse-' + key, JSON.stringify(value)); return true; } catch { return false; } }
  };
  let saved = new Set(storage.get('saved', []).filter(id => articles.some(a => a.id === id)));
  let currentCategory = 'Все';
  let currentArticle = null;
  let readerMode = 'short';
  let currentModal = null;
  let billing = 'year';
  let speaking = false;
  let toastTimer;
  let previousFocus;
  const dialog = $('#modal');
  const modalContent = $('#modal-content');

  function visual(article, reader = false) {
    if (article.image) return `<img src="${article.image}" alt="${escape(article.title)} — иллюстрация" ${reader ? 'class="reader-cover"' : 'loading="lazy"'}>`;
    if (article.id === 'attention') return '<div class="attention-art" aria-hidden="true"><b>24/7</b><small>ПРАВО НА ПАУЗУ</small></div>';
    if (article.id === 'fact') return '<div class="fact-art" aria-hidden="true"><b>✓</b></div>';
    return '<img class="world-art" src="assets/hero.png" alt="Город будущего" loading="lazy">';
  }

  function showToast(message) {
    const toast = $('#toast');
    (dialog.open ? dialog : document.body).append(toast);
    toast.textContent = message;
    toast.classList.add('visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('visible'), 3300);
  }

  function syncSaved() {
    $$('[data-save]').forEach(button => {
      const isSaved = saved.has(button.dataset.save);
      button.classList.toggle('is-saved', isSaved);
      button.setAttribute('aria-pressed', String(isSaved));
      button.setAttribute('aria-label', isSaved ? 'Убрать из сохранённого' : 'Сохранить статью');
      const label = button.querySelector('[data-save-label]');
      if (label) label.textContent = isSaved ? 'Сохранено' : 'Сохранить';
    });
    $('#saved-count').textContent = saved.size;
    $('#saved-count').hidden = saved.size === 0;
  }

  function toggleSave(id) {
    if (!articles.some(a => a.id === id)) return;
    if (saved.has(id)) saved.delete(id); else saved.add(id);
    const persisted = storage.set('saved', [...saved]);
    syncSaved();
    if (currentModal === 'saved') renderSaved();
    showToast(persisted ? (saved.has(id) ? 'Статья добавлена в сохранённое' : 'Статья удалена из сохранённого') : 'Сохранено на время просмотра: браузер ограничил хранение');
  }

  function renderCards(category = 'Все') {
    currentCategory = category;
    const selected = category === 'Все' ? articles.filter(a => !['lead','world'].includes(a.id)) : articles.filter(a => a.category === category);
    $('#article-grid').innerHTML = selected.map(a => `<article class="article-card"><button class="article-image" data-article="${a.id}" aria-label="Читать: ${escape(a.title)}">${visual(a)}<span class="card-type">${a.id === 'fact' ? 'МЕДИАГРАМОТНОСТЬ' : a.id === 'culture' ? 'ВИЗУАЛЬНАЯ ИСТОРИЯ' : 'РАЗБИРАЕМСЯ'}</span></button><div class="card-category"><span>${a.num} / ${a.category.toUpperCase()}</span><button class="icon-button card-save" data-save="${a.id}" aria-label="Сохранить статью">${icon('bookmark')}</button></div><h3><button class="article-title" data-article="${a.id}">${escape(a.title)}</button></h3><p class="article-excerpt">${escape(a.excerpt)}</p><div class="card-bottom"><span>${a.minutes} МИН ЧТЕНИЯ</span><button class="icon-button" data-article="${a.id}" aria-label="Открыть: ${escape(a.title)}">${icon('diagonal')}</button></div></article>`).join('');
    $('#stories-title').innerHTML = `${category === 'Все' ? 'Важное в деталях' : escape(category)}<span class="cyan-text">.</span>`;
    $('#article-total').textContent = String(selected.length).padStart(2,'0') + ' ' + (selected.length === 1 ? 'МАТЕРИАЛ' : 'МАТЕРИАЛА');
    $$('[data-filter]').forEach(b => { b.classList.toggle('active', b.dataset.filter === category); b.setAttribute('aria-pressed', String(b.dataset.filter === category)); });
    $$('[data-category]').forEach(b => b.classList.toggle('active', b.dataset.category === category));
    syncSaved();
  }

  function stopAudio() {
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    speaking = false;
    const b = $('[data-audio]');
    if (b) b.innerHTML = icon('headphones') + 'Озвучить';
  }

  function showModal(type, content) {
    stopAudio();
    currentModal = type;
    modalContent.innerHTML = content;
    if (!dialog.open) { previousFocus = document.activeElement; dialog.showModal(); }
    dialog.scrollTop = 0;
    dialog.setAttribute('aria-label', type === 'article' ? currentArticle.title : ({search:'Поиск по номеру',saved:'Сохранённые статьи',issue:'Первый выпуск Пульса',subscribe:'Подписка на Пульс',style:'Визуальный стиль',sections:'Рубрики газеты',print:'Печатная коллекция',about:'Об издании'})[type] || 'Пульс');
  }

  function closeModal() {
    stopAudio();
    dialog.close();
    currentModal = null;
    if (location.hash.startsWith('#article/')) history.replaceState(null, '', location.pathname + location.search + '#stories');
    if (previousFocus?.isConnected) previousFocus.focus({preventScroll:true});
  }

  function renderReaderBody() {
    const a = currentArticle;
    if (!a) return;
    $('#reader-body').innerHTML = readerMode === 'short'
      ? `<span class="eyebrow">ГЛАВНОЕ ЗА МИНУТУ</span><ul>${a.summary.map(s => `<li>${escape(s)}</li>`).join('')}</ul><button class="line-link" data-mode="full">Перейти к полному материалу ${icon('arrow')}</button><div class="reader-footer">Краткая и полная версии — два формата одного материала. Вы выбираете глубину чтения.</div>`
      : a.sections.map(s => `<section><h3>${escape(s.title)}</h3><p>${escape(s.text)}</p></section>`).join('') + `<div class="reader-footer"><p>${escape(a.closingQuestion || 'Какая мысль из этой истории останется с вами?')}</p><a href="articles/${a.id}/" class="line-link">Открыть статью на отдельной странице ${icon('arrow')}</a></div>`;
    $$('.reader-switch button').forEach(b => { b.classList.toggle('active', b.dataset.mode === readerMode); b.setAttribute('aria-pressed', String(b.dataset.mode === readerMode)); });
  }

  function openArticle(id, updateHash = true) {
    const a = articles.find(a => a.id === id);
    if (!a) return;
    currentArticle = a;
    readerMode = storage.get('reading-mode','short');
    if (updateHash && location.hash !== '#article/' + id) history.pushState(null, '', '#article/' + id);
    showModal('article', `<article><div class="reader-head"><div class="reader-label"><span class="eyebrow">${a.num} / ${a.category.toUpperCase()} · ${a.minutes} МИН ЧТЕНИЯ</span><span class="reader-format">${escape(a.format || "Эссе")} / ПУЛЬС</span></div><h1 class="reader-title">${escape(a.title)}</h1><p class="reader-excerpt">${escape(a.excerpt)}</p><div class="reader-tools"><button data-audio>${icon('headphones')}Озвучить</button><button data-save="${a.id}">${icon('bookmark')}<span data-save-label>Сохранить</span></button><button data-font aria-label="Увеличить размер текста">Aа +</button><button data-copy>${icon('diagonal')}Ссылка</button></div></div>${a.image ? visual(a,true) : `<div class="reader-cover-art">${visual(a,true)}</div>`}<div class="reader-switch" role="group" aria-label="Длина материала"><button class="active" data-mode="short" aria-pressed="true">За минуту</button><button data-mode="full" aria-pressed="false">Полный текст</button></div><div class="reader-body" id="reader-body"></div></article>`);
    renderReaderBody();
    syncSaved();
  }

  function resultsMarkup(list, withSave = false) {
    return `<div class="result-list">${list.map(a => `<div class="result-item"><button data-article="${a.id}"><span class="eyebrow">${a.category.toUpperCase()} / ${a.minutes} МИН</span><h3>${escape(a.title)}</h3><p>${escape(a.excerpt)}</p></button>${withSave ? `<button class="icon-button" data-save="${a.id}" aria-label="Убрать из сохранённого">${icon('bookmark')}</button>` : `<button class="icon-button" data-article="${a.id}" aria-label="Читать: ${escape(a.title)}">${icon('diagonal')}</button>`}</div>`).join('')}</div>`;
  }

  function renderSearch(query = '') {
    const q = query.toLocaleLowerCase('ru').trim();
    const results = articles.filter(a => [a.title,a.excerpt,a.category,...a.summary,...a.sections.map(s=>s.title+' '+s.text)].join(' ').toLocaleLowerCase('ru').includes(q));
    $('#search-results').innerHTML = results.length ? `<span class="eyebrow">${q ? 'НАЙДЕНО: ' + results.length : 'МАТЕРИАЛЫ ПЕРВОГО ВЫПУСКА'}</span>` + resultsMarkup(results) : '<p class="empty-state">Такого материала в этом номере пока нет.<br>Попробуйте «работа», «творчество» или название рубрики.</p>';
  }

  function renderSaved() {
    const selected = articles.filter(a => saved.has(a.id));
    modalContent.innerHTML = `<div class="modal-padding"><span class="eyebrow">ВАША ЛИЧНАЯ ПОДБОРКА</span><h2 class="modal-title">Вернуться к важному<span class="cyan-text">.</span></h2><p class="modal-intro">Сохранённые статьи хранятся в этом браузере.</p>${selected.length ? resultsMarkup(selected,true) : '<div class="empty-state">Здесь появятся статьи, которые вы сохраните.<br>Нажмите на закладку рядом с любым материалом.<button class="primary-button" data-return-stories>Выбрать материал '+icon('arrow')+'</button></div>'}</div>`;
    syncSaved();
  }

  function renderSubscribe() {
    const annual = billing === 'year';
    showModal('subscribe', `<div class="modal-padding"><span class="eyebrow">ПОДПИСКА НА ОСМЫСЛЕННОЕ ЧТЕНИЕ</span><h2 class="modal-title">Больше контекста.<br>Ближе к будущему.</h2><p class="modal-intro">Первый выпуск открыт для чтения. Цифровая и печатная подписки появятся позже — ниже будущие форматы и тарифы.</p><div class="subscription-toggle" role="group" aria-label="Период подписки"><button class="${annual?'active':''}" data-billing="year" aria-pressed="${annual}">На год</button><button class="${!annual?'active':''}" data-billing="month" aria-pressed="${!annual}">На месяц</button></div><div class="plans"><div class="plan featured"><span class="eyebrow">ЦИФРОВАЯ ГАЗЕТА</span><h3>Пульс Digital</h3><div class="plan-price">${annual?'500':'999'} ₽ <small>/ месяц</small></div><p>${annual?'6 000 ₽ при оплате за год':'999 ₽ при ежемесячной оплате'}</p><ul><li>Расширенные материалы</li><li>Тематические подборки и архив</li><li>Текст, аудио и интерактивные истории</li></ul><button class="primary-button" data-modal="issue">Читать первый выпуск ${icon('arrow')}</button></div><div class="plan"><span class="eyebrow">КОЛЛЕКЦИОННАЯ ПЕЧАТЬ</span><h3>Пульс Collection</h3><div class="plan-price">24 000 ₽ <small>/ год</small></div><p>2 000 ₽ в месяц в рамках годовой подписки</p><ul><li>Лимитированные выпуски</li><li>Авторский дизайн и качественная бумага</li><li>Курьерская доставка</li></ul><button class="primary-button" data-modal="print">Посмотреть коллекцию ${icon('arrow')}</button></div></div><p class="local-caption">Отдельный журнал — 1 500 ₽. Приём заказов и платежей ещё не открыт.</p><div id="plan-selection" role="status" class="local-caption"></div></div>`);

  }

  function openInfo(type) {
    if (type === 'search') {
      showModal(type, '<div class="modal-padding"><span class="eyebrow">ПОИСК ПО НОМЕРУ</span><h2 class="modal-title">Что вас волнует?</h2><label class="sr-only" for="search-input">Введите тему или название статьи</label><input type="search" id="search-input" class="search-input" placeholder="Тема, статья или рубрика…" autocomplete="off"><div id="search-results" aria-live="polite"></div></div>');
      renderSearch();
      setTimeout(() => $('#search-input')?.focus(), 60);
    } else if (type === 'saved') {
      showModal(type, ''); renderSaved();
    } else if (type === 'issue') {
      showModal(type, `<div class="modal-padding"><span class="eyebrow">ПЕРВЫЙ ВЫПУСК / № 001</span><h2 class="modal-title">Человек в мире<br>искусственного интеллекта.</h2><p class="modal-intro">Шесть историй о том, как меняется наша работа, творчество, внимание и город вокруг. Выберите тему — читайте в своём ритме.</p>${resultsMarkup(articles)}</div>`);
    } else if (type === 'subscribe') {
      renderSubscribe();
    } else if (type === 'sections') {
      const sections = ['Мир','Будущее','Человек','Культура','Проверено','Голос читателя'];
      showModal(type, `<div class="modal-padding"><span class="eyebrow">ШЕСТЬ РАЗДЕЛОВ — ОДИН МИР</span><h2 class="modal-title">Рубрики</h2><div class="section-list">${sections.map((s,i)=>`<button data-section="${s}"><span>0${i+1}</span>${s}${icon('arrow')}</button>`).join('')}</div></div>`);
    } else if (type === 'about') {
      showModal(type, '<div class="modal-padding"><span class="eyebrow">ЦИФРОВАЯ ГАЗЕТА БУДУЩЕГО</span><h2 class="modal-title">Мир меняется.<br>Мы объясняем почему.</h2><p class="modal-intro">«ПУЛЬС» — цифровая газета о человеке в меняющемся мире. Мы рассматриваем технологии через повседневную жизнь, задаём вопросы и оставляем место для собственной мысли читателя.</p><div class="about-grid"><div><h3>Первая полоса</h3><p>Одна большая тема и конечный набор материалов. Выпуск, который можно прочитать от начала до конца.</p></div><div><h3>В своём ритме</h3><p>Краткая версия для знакомства с темой, полный материал для вдумчивого чтения и озвучивание средствами браузера.</p></div><div><h3>Шесть взглядов</h3><p>Мир, Будущее, Человек, Культура, Проверено и Голос читателя. Разные темы складываются в общую картину.</p></div><div><h3>На любом экране</h3><p>На компьютере — просторная газетная полоса. На телефоне — компактная лента номера с нижней навигацией.</p></div></div><p class="local-caption">Материалы первого выпуска — эссе и разборы о будущем, культуре и информационной среде. Закладки и личные ответы сохраняются на вашем устройстве. Для чтения подписка не нужна.</p></div>');
    } else if (type === 'style') {
      showModal(type, '<div class="modal-padding"><span class="eyebrow">ВИЗУАЛЬНЫЙ ЯЗЫК ИЗДАНИЯ</span><h2 class="modal-title">Газетная ясность.<br>Цифровая энергия.</h2><p class="modal-intro">Крупные заголовки, асимметричная сетка, тонкие линии и свободное пространство. Серебристые изображения связывают технологию с человеком.</p><div class="palette"><div class="swatch" style="background:#f6f7f4">#F6F7F4</div><div class="swatch" style="background:#141719;color:white">#141719</div><div class="swatch" style="background:#00c9ee">#00C9EE</div><div class="swatch" style="background:#c2ff00">#C2FF00</div><div class="swatch" style="background:linear-gradient(100deg,#c1c7cc,#f2f3f3,#9aa3aa)">СЕРЕБРО</div></div><div class="style-wordmark">ПУЛЬС<span class="cyan-text">.</span></div><div class="about-grid"><div><h3>Типографика</h3><p>Плотный гротеск в логотипе, крупные заголовки и спокойный набор текста. Футуристичность без ущерба читаемости.</p></div><div><h3>Акценты</h3><p>Голубой ведёт к главному действию. Лайм выделяет проверку информации и участие читателя.</p></div></div></div>');
    } else if (type === 'print') {
      showModal(type, '<div class="modal-padding"><span class="eyebrow">КОЛЛЕКЦИОННЫЙ ФОРМАТ</span><h2 class="modal-title">Истории, которые остаются.</h2><p class="modal-intro">«ПУЛЬС 2050» — печатная коллекция о мире, который мы создаём. Большие темы, крупная типографика и визуальные истории. Выпуски готовятся к выходу; продажи пока не открыты.</p><img class="print-modal-img" src="assets/print-issues.png" alt="Три обложки печатной коллекции Пульс 2050"><div class="about-grid"><div><h3>Один выпуск</h3><p>Планируемая стоимость коллекционного журнала — 1 500 ₽.</p></div><div><h3>Коллекция на год</h3><p>Планируемая годовая коллекция — 24 000 ₽ с доставкой. О начале продаж сообщим на сайте.</p></div></div><button class="line-link" data-modal="subscribe">Сравнить варианты подписки '+icon('arrow')+'</button></div>');
    }
  }

  function updatePoll() {
    const poll = storage.get('poll', null);
    $('#poll-form').hidden = !!poll;
    $('#poll-result').hidden = !poll;
    if (poll) $('#poll-result').innerHTML = `<span class="small-check dark-check" style="margin-top:24px">✓</span><h4 class="poll-result-title">Ваш ответ сохранён.</h4><p class="poll-result-text">Готовы доверить ИИ:</p><p class="poll-result-answer">${escape(poll.choice)}</p>${poll.boundary?`<p class="poll-result-text">Оставите за собой:</p><p class="poll-result-answer">${escape(poll.boundary)}</p>`:''}<p class="poll-result-text">Вернитесь к этому ответу после чтения номера: изменилось ли ваше отношение к технологиям?</p><button class="line-link" data-revote>Изменить ответ ${icon('arrow')}</button>`;
  }

  function toggleAudio() {
    if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) return showToast('В этом браузере озвучивание недоступно');
    if (speaking) return stopAudio();
    const a = currentArticle;
    const text = a.title + '. ' + (readerMode === 'short' ? a.summary.join('. ') : a.sections.map(s=>s.title+'. '+s.text).join('. '));
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ru-RU';
    const voices = speechSynthesis.getVoices();
    const russianVoice = voices.find(v => v.lang.startsWith('ru'));
    if (russianVoice) utterance.voice = russianVoice;
    utterance.rate = .95;
    utterance.onend = () => { speaking = false; const b=$('[data-audio]'); if(b)b.innerHTML=icon('headphones')+'Озвучить'; };
    utterance.onerror = event => { speaking = false; const b=$('[data-audio]'); if(b)b.innerHTML=icon('headphones')+'Озвучить'; if(!['canceled','interrupted'].includes(event.error))showToast('Браузер не смог озвучить текст. Попробуйте другой браузер.'); };
    speaking = true;
    $('[data-audio]').innerHTML = icon('headphones') + 'Остановить';
    speechSynthesis.speak(utterance);
  }

  document.addEventListener('click', async event => {
    const b = event.target.closest('button,a');
    if (!b) return;
    if (b.hasAttribute('data-save')) { event.preventDefault(); toggleSave(b.dataset.save); }
    else if (b.hasAttribute('data-article')) { if(b.tagName==='A' && (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)) return; event.preventDefault(); openArticle(b.dataset.article); }
    else if (b.hasAttribute('data-modal')) { event.preventDefault(); openInfo(b.dataset.modal); }
    else if (b.hasAttribute('data-close')) { event.preventDefault(); closeModal(); }
    else if (b.hasAttribute('data-filter') || b.hasAttribute('data-category')) {
      event.preventDefault(); renderCards(b.dataset.filter || b.dataset.category);
      history.replaceState(null, '', location.pathname + (currentCategory === 'Все' ? '' : '?category=' + encodeURIComponent(currentCategory)) + (b.dataset.category === 'Все' ? '#main' : '#stories'));
      if (b.hasAttribute('data-category')) $(b.dataset.category === 'Все' ? '#main' : '#stories').scrollIntoView({behavior:'smooth'});
    } else if (b.hasAttribute('data-mode')) {
      stopAudio(); readerMode = b.dataset.mode; storage.set('reading-mode',readerMode); renderReaderBody();
      $('.reader-switch').scrollIntoView({behavior:'smooth',block:'start'});
    } else if (b.hasAttribute('data-audio')) toggleAudio();
    else if (b.hasAttribute('data-font')) {
      const body = $('#reader-body');
      const enlarged = body.dataset.enlarged !== 'true';
      body.dataset.enlarged = String(enlarged);
      body.style.setProperty('--reading-size', enlarged?'21px':'18px');
      b.textContent = enlarged?'Aа −':'Aа +';
      b.setAttribute('aria-label', enlarged?'Уменьшить размер текста':'Увеличить размер текста');
    } else if (b.hasAttribute('data-copy')) {
      try { await navigator.clipboard.writeText(new URL('articles/' + currentArticle.id + '/', location.href).href); showToast('Ссылка на статью скопирована'); }
      catch { showToast('Ссылка на статью — в адресной строке браузера'); }
    } else if (b.hasAttribute('data-billing')) { billing=b.dataset.billing;renderSubscribe(); }
    else if (b.hasAttribute('data-section')) {
      closeModal();
      if (b.dataset.section === 'Голос читателя') $('#voice').scrollIntoView({behavior:'smooth'});
      else { renderCards(b.dataset.section); $('#stories').scrollIntoView({behavior:'smooth'}); }
    } else if (b.hasAttribute('data-return-stories')) { closeModal();$('#stories').scrollIntoView({behavior:'smooth'}); }
    else if (b.hasAttribute('data-revote')) {
      storage.set('poll',null);updatePoll();
    }
  });
  document.addEventListener('input', event => { if(event.target.id==='search-input')renderSearch(event.target.value); });
  $('#poll-form').addEventListener('submit', event => {
    event.preventDefault();
    const data = new FormData(event.target);
    const answer = {choice:data.get('poll'),boundary:String(data.get('boundary')||'').trim()};
    if (storage.set('poll',answer)) { updatePoll(); $('#poll-result').setAttribute('tabindex','-1'); $('#poll-result').focus(); }
    else showToast('Браузер ограничил сохранение. Ответ не отправлен.');
  });
  dialog.addEventListener('cancel', event => { event.preventDefault(); closeModal(); });
  dialog.addEventListener('keydown', event => { if(event.key === 'Escape'){event.preventDefault();event.stopPropagation();closeModal();} }, true);
  dialog.addEventListener('click', event => { if(event.target === dialog){ const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeModal(); } });
  window.addEventListener('popstate', () => { const id=location.hash.match(/^#article\/(\w+)$/)?.[1]; if(id)openArticle(id,false);else if(dialog.open)closeModal(); });
  window.addEventListener('pagehide',stopAudio);
  window.addEventListener('storage',event=>{if(event.key==='pulse-saved'){saved=new Set(storage.get('saved',[]));syncSaved();if(currentModal==='saved')renderSaved();}});
  const initialCategory = new URLSearchParams(location.search).get('category');
  renderCards(['Мир','Будущее','Человек','Культура','Проверено'].includes(initialCategory) ? initialCategory : 'Все');updatePoll();
  const initialArticle = location.hash.match(/^#article\/(\w+)$/)?.[1];
  if(initialArticle)openArticle(initialArticle,false);
})();
