(() => {
  'use strict';
  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const id = document.body.dataset.articleId;
  let readingMode = 'full';
  let speaking = false;
  let utterance = null;
  let toastTimer;
  const storage = {
    get(key, fallback) { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; } }
  };
  const savedIds = () => { const data = storage.get('pulse-saved', []); return Array.isArray(data) ? data.filter(item => typeof item === 'string') : []; };
  let saved = new Set(savedIds());
  $$('.js-only').forEach(element => { element.hidden = false; });

  function toast(message) {
    $('#toast').textContent = message;
    $('#toast').classList.add('visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => $('#toast').classList.remove('visible'), 4200);
  }
  function syncSaved() {
    const active = saved.has(id);
    $('[data-save]').classList.toggle('is-saved', active);
    $('[data-save]').setAttribute('aria-pressed', String(active));
    $('[data-save-label]').textContent = active ? 'Сохранено' : 'Сохранить';
  }
  function resetAudioButton() {
    speaking = false;
    $('[data-audio]').setAttribute('aria-pressed', 'false');
    $('[data-audio-label]').textContent = 'Озвучить';
  }
  function stopAudio() {
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    resetAudioButton();
    utterance = null;
  }
  function setMode(mode) {
    stopAudio();
    readingMode = mode === 'short' ? 'short' : 'full';
    $('#short-version').hidden = readingMode !== 'short';
    $('#full-version').hidden = readingMode !== 'full';
    $$('.page-reading-switch [data-mode]').forEach(button => {
      const active = button.dataset.mode === readingMode;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }
  function toggleAudio() {
    if (speaking) return stopAudio();
    if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) return toast('Озвучивание недоступно в этом браузере.');
    const body = readingMode === 'short' ? $$('#short-version li').map(item => item.textContent).join('. ') : $('#full-version').innerText;
    utterance = new SpeechSynthesisUtterance($('h1').textContent + '. ' + body);
    utterance.lang = 'ru-RU';
    utterance.rate = 0.95;
    const voice = speechSynthesis.getVoices().find(item => item.lang.toLowerCase().startsWith('ru'));
    if (voice) utterance.voice = voice;
    utterance.onend = resetAudioButton;
    utterance.onerror = event => {
      resetAudioButton();
      if (!['canceled', 'interrupted'].includes(event.error)) toast('Не удалось начать озвучивание. Проверьте доступность голоса в браузере.');
    };
    speaking = true;
    $('[data-audio]').setAttribute('aria-pressed', 'true');
    $('[data-audio-label]').textContent = 'Остановить';
    speechSynthesis.speak(utterance);
  }
  document.addEventListener('click', async event => {
    const button = event.target.closest('button, a');
    if (!button) return;
    if (button.hasAttribute('data-save')) {
      saved = new Set(savedIds());
      if (saved.has(id)) saved.delete(id); else saved.add(id);
      const persisted = storage.set('pulse-saved', [...saved]);
      syncSaved();
      toast(persisted ? saved.has(id) ? 'Статья сохранена в этом браузере.' : 'Статья удалена из сохранённого.' : 'Выбор сохранён до закрытия страницы: браузер ограничил хранение.');
    } else if (button.hasAttribute('data-mode')) {
      setMode(button.dataset.mode);
      $('.page-reading-switch').scrollIntoView({ block: 'start', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    } else if (button.hasAttribute('data-section-link')) {
      if (readingMode !== 'full') setMode('full');
    } else if (button.hasAttribute('data-font')) {
      const enlarged = $('#article-text').classList.toggle('is-enlarged');
      button.setAttribute('aria-pressed', String(enlarged));
      button.setAttribute('aria-label', enlarged ? 'Обычный размер текста' : 'Увеличить размер текста');
      $('[data-font-label]').textContent = enlarged ? 'Обычно' : 'Крупнее';
    } else if (button.hasAttribute('data-audio')) {
      toggleAudio();
    } else if (button.hasAttribute('data-share')) {
      const url = $('link[rel="canonical"]').href;
      try {
        await navigator.clipboard.writeText(url);
        toast('Ссылка на статью скопирована.');
      } catch {
        const field = document.createElement('textarea');
        field.value = url;
        field.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
        document.body.append(field);
        field.select();
        let copied = false;
        try { copied = document.execCommand('copy'); } catch { /* Use visible address fallback. */ }
        field.remove();
        button.focus({ preventScroll: true });
        toast(copied ? 'Ссылка на статью скопирована.' : 'Скопируйте ссылку из адресной строки браузера.');
      }
    } else if (button.hasAttribute('data-print')) {
      stopAudio();
      window.print();
    }
  });
  window.addEventListener('storage', event => { if (event.key === 'pulse-saved') { saved = new Set(savedIds()); syncSaved(); } });
  window.addEventListener('pagehide', stopAudio);
  syncSaved();
})();
